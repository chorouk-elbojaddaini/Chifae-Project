function toggle(){
    var blur=document.getElementById("blur");
    blur.classList.toggle('active');
    var boite = document.getElementById('boite');
    boite.classList.toggle('active');
}